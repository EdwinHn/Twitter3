/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.twitter3;

/**
 *
 * @author edwinhernandezlopez
 */
public class Twitter3 {

    public static void main(String[] args) {

        
        new Menu_Inicio().setLocationRelativeTo(null);
        new Menu_Inicio().setVisible(true);
        
    }
}
